package squarecube;
import java.util.Scanner;
public class SquareCube {
    
    public static void main(String[] args) {
        
        System.out.println("\n*** Welcome to the Squares and Cubes Table ***");
        Scanner sc = new Scanner(System.in);
        char choice = 'y';
        
        do{
            System.out.print("\nEnter an Integer: ");
            int x = sc.nextInt();
            
            System.out.println("\nNumber \t\tSquared \tCubed");
            System.out.println("====== \t\t======= \t=====");

            for (int i = 1; i <= x; i++){
                
                int square = i * i;
                int cube = i * i * i;
                
                System.out.printf("%d \t\t%d \t\t%d \n", i, square, cube);
            }
            
            System.out.print("\nContinue? (y/n): ");
            choice = sc.next().charAt(0);
            
        }while(choice == 'y' || choice == 'Y');
    }
}
