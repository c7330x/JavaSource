package calculateinterest;

import java.util.Scanner;
import java.text.DecimalFormat;
//import java.math.BigDecimal;

public class CalculateInterest {

    public static void main(String[] args) {
        
        System.out.println("\n*** Welcome to the Interest Calculator ***");
        
        Scanner sc = new Scanner(System.in);
        char choice = 'y';
        
        do{
            //Inputs
            System.out.print("\nEnter Loan Amount: \t");
            double principal = sc.nextDouble();
            System.out.print("Enter Interest Rate: \t");
            double rate = sc.nextDouble();
            double rateConv = rate*100;
            
            //outputs
            System.out.printf("\nLoan Amount: \t\t$%,.2f", principal);
            
            DecimalFormat interestFormat = new DecimalFormat("#.###");
            System.out.print("\nInterest Rate: \t\t" +interestFormat.format(rateConv) +"%");
            //System.out.printf("\nInterest Rate: \t\t%.3f%%", rateConv);
            
            double interest = principal * rate;
            System.out.printf("\nInterest: \t\t$%,.2f", interest);
            
            
            //continue
            System.out.print("\n\nContinue? (y/n): ");
            choice = sc.next().charAt(0);
            
        }while(choice == 'y' || choice == 'Y');  
        
    }
}

/* This application should use the BigDecimal class to make sure that all calculations
are accurate. It should round the interest that’s calculated to two decimal places,
rounding up if the third decimal place is five or greater.
*/