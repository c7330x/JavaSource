package my.accounts;

import my.customers.CustomerAccount;

public enum AccountType {
    
    STUDENT(),
    ONE_PERCENTER(),
    AVERAGE_GUY();
    
    public static String handleNSF(CustomerAccount ca) {
        String msg = null;
        
        switch (ca.getAcctType()){
            case STUDENT:
                ca.getAccountNumber().setBalance(
                        ca.getAccountNumber().getBalance() - 35.);
                msg = "Don't spend more than you have!!! – BE A GOOD CITIZEN!!";
                break;
            case AVERAGE_GUY:
                ca.getAccountNumber().setBalance(
                        ca.getAccountNumber().getBalance() - 20.);
                msg = "Seems that you spent a bit much this time";
                break;
            case ONE_PERCENTER:
                 ca.getAccountNumber().setBalance(
                        ca.getAccountNumber().getBalance() + 35000.);
                msg = "Seems like it’s time for another bailout  ;)";
                break;
        } //end switch
        msg +=" \n\tYour new balance is " + 
            ca.getAccountNumber().getBalance();
        return msg;
    } //end method handleNSF 
}
