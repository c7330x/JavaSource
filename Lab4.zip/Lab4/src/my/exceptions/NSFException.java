package my.exceptions;

public class NSFException extends Exception {

    public NSFException() {
    }

    public NSFException(String msg) {
        super(msg);
    }
}
