package my.apps;

import my.bankaccounts.BankAccount;
import my.customers.CustomerAccount;

import my.accounts.AccountType;
import my.exceptions.NSFException;

public class TestThisStuff {

    public static void main(String[] args) {
        
        CustomerAccount student = new CustomerAccount("Joe Student", new BankAccount(123.35), AccountType.STUDENT);
        CustomerAccount richGuy = new CustomerAccount("Daddy Warbucks", new BankAccount(100000), AccountType.ONE_PERCENTER);
        
        try {
            
            //student.getAccountNumber().withdraw(355.23);
            richGuy.getAccountNumber().withdraw(111111.11);
        
        } catch (NSFException ex) {
            
            System.out.println(AccountType.handleNSF(student));

        }  
    }
}
