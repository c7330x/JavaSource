/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package my.bankaccounts;

import my.exceptions.NSFException;

/**
 *
 *
 * BankAccount
 *
 * 
 * Oct 6, 2011
 *
 * @author JConnolly
 */
public class BankAccount {

    /**
     * Current balance of the account
     */
    private double balance;

    public BankAccount(double balance) {
        this.balance = balance;
    }

    /**
     * 
     * @param amount Amount to withdraw from the account
     * @return the new balance for the account
     * @throws NSFException 
     */
    public double withdraw(double amount) throws NSFException {

        double tmpBalance = balance;

        tmpBalance -= amount;

        if (tmpBalance < 0) {
            throw new NSFException();
        } //end if

        setBalance(tmpBalance);
        return getBalance();

    } //end method withdraw

    /**
     * @return the balance
     */
    public double getBalance() {
        return balance;
    }

    /**
     * @param balance the balance to set
     */
    public void setBalance(double balance) {
        this.balance = balance;
    }
}