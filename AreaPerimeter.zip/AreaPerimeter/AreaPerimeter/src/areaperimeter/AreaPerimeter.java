package areaperimeter;
import java.util.Scanner;
public class AreaPerimeter {

    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        System.out.println("\n*** Area & Perimeter Calculator ***");
        char choice = 'y';
        
        do{
            System.out.print("\nEnter Length: ");
            double length = sc.nextDouble();
            System.out.print("Enter Width: ");
            double width = sc.nextDouble();
            double area = length * width;
            double perimeter = (2 * length) + (2 * width);
            System.out.println("\nArea: " + area);
            System.out.println("Perimeter; " + perimeter);
            System.out.print("\nContinue? (Y/N): ");
            choice = sc.next().charAt(0);   
        }while(choice == 'y' || choice == 'Y');
    }
}