package my.change;
//constants that are also objecta
public enum Change {
 
    QUARTER("Quarter", 25),
    DIME("Dime", 10),
    NICKEL("Nickel", 5), 
    PENNY("Penny", 1); 
     
    private final String coinName;
    private final int coinValue;
    
    Change(String name, int value){
        coinName = name;
        coinValue = value;
    }
    
    @Override
    public String toString() {
        return getCoinName();
    }
    public String getCoinName(){
        return coinName;
    }
    
    public int getCoinValue(){
        return coinValue;
    }
}


