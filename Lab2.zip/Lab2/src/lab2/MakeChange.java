package lab2;
import java.util.Scanner;
import my.change.Change;

public class MakeChange {

    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        char choice = 'y';
        
        System.out.println("\n *** Welcome to the Change Calculator ***");
        
        do{
            
            System.out.print("\nEnter Amount (0-100): ");
            int val = sc.nextInt();
            System.out.println("");
            
            if (val <= 100 && val >= 0){
            
                for (Change c : Change.values()){

                    int coins = val / c.getCoinValue();
                    System.out.print("There " + (coins == 1 ? "is " : "are ") + coins + " " + c.getCoinName());

                    if (coins != 1){
                        
                        switch (c) {
                            case QUARTER:
                            case DIME:
                            case NICKEL:
                                System.out.println("s");
                                break;
                            case PENNY:
                                System.out.println("\bies");
                                break;     
                        }
                    } else {
                        System.out.println("");
                    }
                   
                    val = val % c.getCoinValue();
                }

                System.out.print("\nContinue? (y/n): ");
                choice = sc.next().charAt(0);
            
            } else {   
                System.out.println("INVALID ENTRY");
                System.out.println("Please Enter a Valid Entry (0-100)");
                choice = 'y';
            }
            
        } while (choice == 'y' || choice == 'Y');
    }
}
