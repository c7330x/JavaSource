package calculatechange;

import java.util.Scanner;

public class CalculateChange {
    
    public static void main(String[] args){
        
        Scanner sc = new Scanner(System.in);
        char choice = 'y';
        
        System.out.println("\n*** Welcome to the Change Calculator ***");
        
        do{
           
            System.out.print("\nEnter Number of Cents (0-99): ");
            int cents = sc.nextInt();
           
            if(cents >= 0 && cents <= 99){
                
                int quarters = cents / 25;
                cents = cents % 25;
                System.out.println("Quarters: \t" + quarters);
                int dimes = cents / 10;
                cents = cents % 10;
                System.out.println("Dimes: \t\t" + dimes);
                int nickels = cents / 5;
                cents = cents % 5;
                System.out.println("Nickels: \t" + nickels);
                int pennies = cents / 1;
                cents = cents % 1;
                System.out.println("Pennies: \t" + pennies);
                
                System.out.print("\nContinue? (y/n): ");
                choice = sc.next().charAt(0);
            
            }else{
                
                System.out.println("\nINVALID ENTRY");
                System.out.println("Please Enter a valid Amount (0-99)");
                choice = 'y';
            
            }

        }while(choice == 'y' || choice == 'Y');
    }
}
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    