package fahrenheitcelsius;

import java.text.DecimalFormat;
import java.util.Scanner;

public class FahrenheitCelsius {

    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        char choice = 'y';
        
        System.out.println("\n*** Welcome to the Temperature Converter ***");
        
        do{
            //input
            System.out.print("\nEnter degrees in Fahrenheit: ");
            double fahrenheit = sc.nextDouble();
            double celsius = (fahrenheit-32) * 5/9;
            //output
            DecimalFormat celsiusFormat = new DecimalFormat("#.##"); 
            System.out.print("Degrees in Celsius: " +celsiusFormat.format(celsius));
            //loop
            System.out.print("\nContinue: (y/n): ");
            choice = sc.next().charAt(0); 
            
        }while(choice == 'y' || choice == 'Y');
    }
}