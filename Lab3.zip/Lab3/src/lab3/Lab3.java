package lab3;

import java.util.Scanner;

public class Lab3 {
    
    public static void main(String[] args) {
      
        Scanner sc = new Scanner(System.in);
        int input;
        char choice = 'y';
        
        System.out.println("\n*** Welcome to the Factorial Calculator ***");
        
        do{
            
            System.out.print("\nEnter an integer that's greater than 0 and less than 10: ");
            input = sc.nextInt();
            
            if (input <= 10 && input >=0){
                
                long factorial = 1;
                
                for (int i = 1; i <= input; i++){
                   
                    factorial *= i;
                
                }
                
                System.out.printf("The factorial of %d is %d.\n", input, factorial);
                
                System.out.print("\nContinue? (y/n): ");
                choice = sc.next().charAt(0);
                
            } else {
                
                System.out.println("Please enter a valid integer (0-10)...");
                choice = 'y';
                
            }
            
        } while (choice == 'y' || choice == 'Y');   
    }
}
