package numericalgrade;
import java.util.Scanner;
public class NumericalGrade {

    public static void main(String[] args) {
        System.out.println("\n*** Numerical Grade Converter ***");
        Scanner sc = new Scanner(System.in);
        char choice = 'y';
        
        do{
            System.out.print("\nEnter Numerical Grade: ");
            int numericalGrade = sc.nextInt();
            if((numericalGrade >= 88) && (numericalGrade <= 100)){
                System.out.println("Letter Grade: A");
            } else if ((numericalGrade >= 80) && (numericalGrade <= 87)){
                System.out.println("Letter Grade: B");
            } else if ((numericalGrade >= 70) && (numericalGrade <= 79)){
                System.out.println("Letter Grade: C");
            } else if ((numericalGrade >= 60) && (numericalGrade <= 69)){
                System.out.println("Letter Grade: D");
            } else if ((numericalGrade >= 0) && (numericalGrade <= 59)){
                System.out.println("Letter Grade: F");
            } else {
                System.out.println("INVALID ENTRY");
                System.out.println("Please Enter A Value Between 0 - 100");
            }
            System.out.print("\nContinue? (Y/N): ");
            choice = sc.next().charAt(0);
                
        }while(choice == 'y' || choice == 'Y');
    }
}